# Project Title: Simple Chatbot with Knowledge Base and Appointment Handling

## 1. Description / Objective

This project implements a simple chatbot capable of answering predefined questions from a knowledge base and handling appointment scheduling using JSON data. It's designed to demonstrate basic natural language processing, data management, and chatbot interactions using Python.

---

## 2. Necessary Libraries / Installation Requirements

Install the required libraries by running:

```bash
pip install -r requirements.txt
```

Alternatively, you can install the necessary libraries manually:

```bash
pip install nltk
```

> **Note:** If NLTK data is required (e.g., for tokenization or similarity), run:

```python
import nltk
nltk.download('punkt')
```

---

## 3. Commands to Run the Project

Copy and paste the following commands into your terminal:

```bash
# Step 1: Clone the repository
git clone https://github.com/yourusername/simple-chatbot.git

# Step 2: Navigate into the project directory
cd simple-chatbot

# Step 3: Install dependencies
pip install -r requirements.txt

# Step 4: Run the chatbot script
python Chatbot.py.py
```

---

## 4. File Structure

```
simple-chatbot/
│
├── README.md               # Project overview and setup instructions
├── requirements.txt        # List of dependencies
├── Chatbot.py.py           # Main chatbot script
├── Knowledge_Base.json     # JSON file with predefined Q&A for chatbot
└── appointments.json       # JSON file for appointment data storage
```

---

> **Note:** Ensure `Knowledge_Base.json` and `appointments.json` are present in the root directory for the chatbot to function correctly.

Happy chatting! 🤖✨
