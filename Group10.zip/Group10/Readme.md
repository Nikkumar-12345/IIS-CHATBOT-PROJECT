
# Project Title: Simple Chatbot with Knowledge Base and Appointment Handling

## 1. Description / Objective

This project implements a simple chatbot capable of answering predefined questions from a knowledge base and handling appointment scheduling using JSON data. It's designed to demonstrate basic natural language processing, data management, and chatbot interactions using Python.

The chatbot supports:
- Multilingual interaction using text-to-speech and translation.
- Secure visitor data storage with encryption.
- Voice input for enhanced user experience.
- Appointment management: booking, rescheduling, and cancellation.
- PDF report generation for scheduled appointments.

---

## 2. Necessary Libraries / Installation Requirements

To run this project, the following Python libraries are required:

| Library             | Purpose                                                                 |
|---------------------|-------------------------------------------------------------------------|
| `os`                | Accessing file paths and environment handling                          |
| `json`              | Reading and writing JSON data                                           |
| `re`                | Regular expression operations for string parsing                        |
| `datetime`          | Handling date and time formats                                          |
| `reportlab`         | Generating PDF appointment reports                                      |
| `speech_recognition`| Capturing and converting voice input to text                            |
| `getpass`           | Secure password input for admin login                                   |
| `cryptography`      | Encrypting and decrypting sensitive visitor data                        |
| `googletrans`       | Translating chatbot responses into multiple languages                   |
| `asyncio`           | Asynchronous execution for speech synthesis                            |
| `edge_tts`          | Text-to-speech conversion using Edge neural voices                      |
| `tempfile`          | Creating temporary files for TTS output                                 |
| `playsound`         | Playing the generated speech output (MP3 files)                         |

You can install the required libraries using:

```bash
pip install -r requirements.txt
```

> **Note:** Create a `requirements.txt` file with the following content:

```
reportlab
speechrecognition
cryptography
googletrans==4.0.0rc1
asyncio
edge-tts
playsound
```

---

## 3. Commands to Run the Project

Open a terminal or command prompt and run the following commands:

```bash
# Step 1: Clone the repository
git clone https://github.com/Nikkumar-12345/IIS-CHATBOT-PROJECT

# Step 2: Navigate into the project directory
cd IIS-CHATBOT-PROJECT

# Step 3: Install dependencies
pip install -r requirements.txt

# Step 4: Run the chatbot script
python Chatbot.py
```

---

## 4. File Structure

```
IIS-CHATBOT-PROJECT/
│
├── README.md               # Project overview and setup instructions
├── requirements.txt        # List of dependencies
├── Chatbot.py.py           # Main chatbot script
├── Knowledge_Base.json     # JSON file with predefined Q&A for chatbot
└── appointments.json       # JSON file for appointment data storage
```

---

## 5. Additional Notes

- Ensure `Knowledge_Base.json` and `appointments.json` are located in the root directory.
- The chatbot supports English, French, Spanish, Hindi, and Japanese.
- Voice functionality is powered by Microsoft's `edge-tts`, and responses are read aloud to the user.
- Appointment confirmation PDFs are automatically generated and saved locally.

---

Happy chatting! 🤖✨
